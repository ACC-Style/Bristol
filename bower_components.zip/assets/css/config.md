# Styleguide options

### Head

	link(rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,700italic,700,600,400,300|Roboto+Slab:400,700|Raleway:300" rel="stylesheet" type="text/css")
    link(rel="stylesheet" href="/assets/css/style.css")
    link(rel='stylesheet' href='css/styledown.css')
    script(src='https://cdn.rawgit.com/styledown/styledown/v1.0.2/data/styledown.js')

### Body

    h1 My Awesome Styleguides
    div#styleguides(sg-content)